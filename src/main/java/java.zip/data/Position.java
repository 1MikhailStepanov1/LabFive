package data;

public enum Position {
    MANAGER,
    LABORER,
    LEAD_DEVELOPER,
    BAKER,
    MANAGER_OF_CLEANING
}
