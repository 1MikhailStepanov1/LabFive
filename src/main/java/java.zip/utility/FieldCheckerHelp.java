package utility;

public interface FieldCheckerHelp<T> {
    T check(String str);
}
